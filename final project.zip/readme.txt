you need all the files to run this project
for all the files download final project.zip
1) run project.py
2) click on any button
3) enter the required values with the right units
4) enjoy the simulation!!!!!